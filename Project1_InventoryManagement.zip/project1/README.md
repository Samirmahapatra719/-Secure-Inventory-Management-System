# Secure Inventory Management System

A full-stack Java/Spring Boot REST API with role-based access control, JPA data access,
JWT authentication, and a scheduled batch job for low-stock alerts.

## Tech Stack
- **Java 17** + **Spring Boot 3.2**
- **Spring Data JPA** (Hibernate) — Data Access Framework
- **Spring Security** + **JWT** — Authentication & Authorization
- **H2 In-Memory DB** (swap to MySQL for production)
- **Maven** — Build tool
- **JUnit 5** + **Mockito** — Unit testing

## IBM Criteria Covered
| Requirement | Implementation |
|---|---|
| Java Programming | Spring Boot REST API, all layers in Java |
| SDLC Concepts | Layered architecture, Git, JUnit tests, documentation |
| Data Access Frameworks | Spring Data JPA with custom JPQL queries |
| Batch Processing | `@Scheduled` low-stock alert job |
| CyberSecurity | JWT auth, role-based access, BCrypt passwords |

## Roles
| Role | Permissions |
|---|---|
| ADMIN | Full CRUD + delete + trigger batch jobs |
| MANAGER | Create & update products (no delete) |
| VIEWER | Read-only access |

## Quick Start
```bash
# Build and run
mvn spring-boot:run

# H2 Console (browser)
http://localhost:8080/h2-console
# JDBC URL: jdbc:h2:mem:inventorydb   User: sa   Password: (empty)
```

## API Endpoints

### Auth
```
POST /api/auth/login      { "username":"admin", "password":"admin123" }
POST /api/auth/register   { "username":"x", "password":"x", "email":"x@x.com" }
```

### Products (add header: Authorization: Bearer <token>)
```
GET    /api/products               Get all products
GET    /api/products/{id}          Get by ID
GET    /api/products/search?name=  Search by name
GET    /api/products/category/{c}  Filter by category
GET    /api/products/low-stock     Items below threshold
GET    /api/products/summary/categories  Category counts
POST   /api/products               Create (ADMIN/MANAGER)
PUT    /api/products/{id}          Update (ADMIN/MANAGER)
DELETE /api/products/delete/{id}   Delete (ADMIN only)
```

### Admin
```
POST /api/admin/trigger-stock-check   Manually run batch job (ADMIN only)
```

## Project Structure
```
src/
├── main/java/com/ibm/inventory/
│   ├── model/          (Product, User, Role)
│   ├── repository/     (JPA Repositories with custom queries)
│   ├── service/        (Business logic layer)
│   ├── controller/     (REST endpoints)
│   ├── security/       (JWT, Spring Security config)
│   └── scheduler/      (Low-stock batch alert job)
└── test/               (JUnit 5 + Mockito tests)
```

## Running Tests
```bash
mvn test
```
