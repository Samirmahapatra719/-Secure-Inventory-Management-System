package com.ibm.inventory;

import com.ibm.inventory.model.Product;
import com.ibm.inventory.repository.ProductRepository;
import com.ibm.inventory.service.ProductService;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.extension.ExtendWith;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.junit.jupiter.MockitoExtension;
import org.springframework.test.util.ReflectionTestUtils;

import java.math.BigDecimal;
import java.util.List;
import java.util.Optional;

import static org.junit.jupiter.api.Assertions.*;
import static org.mockito.Mockito.*;

@ExtendWith(MockitoExtension.class)
class ProductServiceTest {

    @Mock
    private ProductRepository productRepository;

    @InjectMocks
    private ProductService productService;

    private Product sampleProduct;

    @BeforeEach
    void setUp() {
        ReflectionTestUtils.setField(productService, "lowStockThreshold", 10);
        sampleProduct = new Product(1L, "Laptop", "Electronics", 45, new BigDecimal("75000.00"), "Dell XPS");
    }

    @Test
    void testGetAllProducts_returnsAllProducts() {
        when(productRepository.findAll()).thenReturn(List.of(sampleProduct));
        List<Product> result = productService.getAllProducts();
        assertEquals(1, result.size());
        assertEquals("Laptop", result.get(0).getName());
        verify(productRepository, times(1)).findAll();
    }

    @Test
    void testGetProductById_existingId_returnsProduct() {
        when(productRepository.findById(1L)).thenReturn(Optional.of(sampleProduct));
        Product result = productService.getProductById(1L);
        assertNotNull(result);
        assertEquals("Laptop", result.getName());
    }

    @Test
    void testGetProductById_nonExistingId_throwsException() {
        when(productRepository.findById(99L)).thenReturn(Optional.empty());
        RuntimeException ex = assertThrows(RuntimeException.class, () -> productService.getProductById(99L));
        assertTrue(ex.getMessage().contains("99"));
    }

    @Test
    void testCreateProduct_savesAndReturnsProduct() {
        when(productRepository.save(sampleProduct)).thenReturn(sampleProduct);
        Product result = productService.createProduct(sampleProduct);
        assertEquals("Laptop", result.getName());
        verify(productRepository).save(sampleProduct);
    }

    @Test
    void testGetLowStockProducts_returnsLowStockItems() {
        Product lowStock = new Product(2L, "Mouse", "Electronics", 3, new BigDecimal("1500"), "Wireless");
        when(productRepository.findLowStockProducts(10)).thenReturn(List.of(lowStock));
        List<Product> result = productService.getLowStockProducts();
        assertEquals(1, result.size());
        assertTrue(result.get(0).getQuantity() < 10);
    }

    @Test
    void testDeleteProduct_existingId_deletesSuccessfully() {
        when(productRepository.existsById(1L)).thenReturn(true);
        assertDoesNotThrow(() -> productService.deleteProduct(1L));
        verify(productRepository).deleteById(1L);
    }

    @Test
    void testDeleteProduct_nonExistingId_throwsException() {
        when(productRepository.existsById(99L)).thenReturn(false);
        assertThrows(RuntimeException.class, () -> productService.deleteProduct(99L));
    }

    @Test
    void testUpdateProduct_updatesAllFields() {
        Product updated = new Product(null, "Updated Laptop", "Electronics", 50, new BigDecimal("80000"), "Updated");
        when(productRepository.findById(1L)).thenReturn(Optional.of(sampleProduct));
        when(productRepository.save(any(Product.class))).thenAnswer(inv -> inv.getArgument(0));
        Product result = productService.updateProduct(1L, updated);
        assertEquals("Updated Laptop", result.getName());
        assertEquals(50, result.getQuantity());
    }
}
