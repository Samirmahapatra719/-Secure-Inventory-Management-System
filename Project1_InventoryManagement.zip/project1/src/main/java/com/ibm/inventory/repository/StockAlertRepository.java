package com.ibm.inventory.repository;

import com.ibm.inventory.model.StockAlert;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;
import org.springframework.stereotype.Repository;

import java.util.List;

@Repository
public interface StockAlertRepository extends JpaRepository<StockAlert, Long> {

    List<StockAlert> findByStatus(StockAlert.AlertStatus status);

    @Query("SELECT s FROM StockAlert s WHERE s.status = 'OPEN' ORDER BY s.alertedAt DESC")
    List<StockAlert> findAllOpenAlerts();

    @Query("SELECT s FROM StockAlert s WHERE s.product.id = :productId ORDER BY s.alertedAt DESC")
    List<StockAlert> findByProductId(Long productId);
}
