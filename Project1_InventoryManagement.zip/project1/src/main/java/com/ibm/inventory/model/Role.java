package com.ibm.inventory.model;

public enum Role {
    ADMIN,
    MANAGER,
    VIEWER
}
