package com.ibm.inventory.repository;

import com.ibm.inventory.model.Product;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.query.Param;

import java.util.List;

public interface ProductRepository extends JpaRepository<Product, Long> {

    // Find products by category
    List<Product> findByCategory(String category);

    // Search by name (case-insensitive)
    List<Product> findByNameContainingIgnoreCase(String name);

    // Low stock query - used by the scheduler
    @Query("SELECT p FROM Product p WHERE p.quantity < :threshold")
    List<Product> findLowStockProducts(@Param("threshold") int threshold);

    // Products by category ordered by quantity
    @Query("SELECT p FROM Product p WHERE p.category = :category ORDER BY p.quantity ASC")
    List<Product> findByCategoryOrderByQuantity(@Param("category") String category);

    // Total product count per category
    @Query("SELECT p.category, COUNT(p) FROM Product p GROUP BY p.category")
    List<Object[]> countProductsByCategory();
}
