package com.ibm.inventory.scheduler;

import com.ibm.inventory.model.Product;
import com.ibm.inventory.service.ProductService;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.scheduling.annotation.Scheduled;
import org.springframework.stereotype.Component;

import java.time.LocalDateTime;
import java.util.List;

/**
 * Scheduled batch job that checks inventory levels and generates alerts.
 * Runs daily at 9 AM (configurable via application.properties).
 * This demonstrates IBM's "Batch Processing" requirement.
 */
@Component
public class LowStockAlertScheduler {

    private static final Logger logger = LoggerFactory.getLogger(LowStockAlertScheduler.class);

    @Autowired
    private ProductService productService;

    /**
     * Scheduled job - runs every day at 9 AM.
     * For demo, set to every 60 seconds: fixedRate = 60000
     */
    @Scheduled(cron = "${app.scheduler.cron}")
    public void checkLowStockAndAlert() {
        logger.info("=== BATCH JOB STARTED: Low Stock Check at {} ===", LocalDateTime.now());

        List<Product> lowStockProducts = productService.getLowStockProducts();

        if (lowStockProducts.isEmpty()) {
            logger.info("All products are sufficiently stocked.");
        } else {
            logger.warn("LOW STOCK ALERT: {} products below threshold of {}",
                    lowStockProducts.size(), productService.getLowStockThreshold());

            for (Product p : lowStockProducts) {
                logger.warn("  [LOW STOCK] Product: '{}' | Category: {} | Quantity: {} | Price: {}",
                        p.getName(), p.getCategory(), p.getQuantity(), p.getPrice());
            }

            // In production, this would send an email:
            // mailService.sendLowStockAlert(lowStockProducts);
            generateAlertReport(lowStockProducts);
        }

        logger.info("=== BATCH JOB COMPLETED ===");
    }

    private void generateAlertReport(List<Product> products) {
        StringBuilder report = new StringBuilder();
        report.append("\n======================================\n");
        report.append("       LOW STOCK ALERT REPORT\n");
        report.append("  Generated: ").append(LocalDateTime.now()).append("\n");
        report.append("======================================\n");
        report.append(String.format("%-5s %-20s %-15s %-10s%n", "ID", "Name", "Category", "Qty"));
        report.append("--------------------------------------\n");

        for (Product p : products) {
            report.append(String.format("%-5d %-20s %-15s %-10d%n",
                    p.getId(), p.getName(), p.getCategory(), p.getQuantity()));
        }

        report.append("======================================\n");
        report.append("Action Required: Restock the above items immediately.\n");

        logger.warn(report.toString());
    }

    // Also allow manual trigger via API
    public String triggerManualCheck() {
        List<Product> lowStockProducts = productService.getLowStockProducts();
        checkLowStockAndAlert();
        return "Manual check complete. Found " + lowStockProducts.size() + " low stock items.";
    }
}
