package com.ibm.inventory;

import com.ibm.inventory.model.Product;
import com.ibm.inventory.model.Role;
import com.ibm.inventory.model.User;
import com.ibm.inventory.repository.ProductRepository;
import com.ibm.inventory.repository.UserRepository;
import org.springframework.boot.CommandLineRunner;
import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;
import org.springframework.context.annotation.Bean;
import org.springframework.scheduling.annotation.EnableScheduling;
import org.springframework.security.crypto.password.PasswordEncoder;

import java.math.BigDecimal;

@SpringBootApplication
@EnableScheduling
public class InventoryApplication {

    public static void main(String[] args) {
        SpringApplication.run(InventoryApplication.class, args);
    }

    // Seed data on startup for demo purposes
    @Bean
    CommandLineRunner seedData(UserRepository userRepo, ProductRepository productRepo, PasswordEncoder encoder) {
        return args -> {
            // Create admin user
            User admin = new User();
            admin.setUsername("admin");
            admin.setPassword(encoder.encode("admin123"));
            admin.setEmail("admin@inventory.com");
            admin.setRole(Role.ADMIN);
            userRepo.save(admin);

            // Create manager user
            User manager = new User();
            manager.setUsername("manager");
            manager.setPassword(encoder.encode("manager123"));
            manager.setEmail("manager@inventory.com");
            manager.setRole(Role.MANAGER);
            userRepo.save(manager);

            // Create viewer user
            User viewer = new User();
            viewer.setUsername("viewer");
            viewer.setPassword(encoder.encode("viewer123"));
            viewer.setEmail("viewer@inventory.com");
            viewer.setRole(Role.VIEWER);
            userRepo.save(viewer);

            // Seed some products
            productRepo.save(new Product(null, "Laptop", "Electronics", 45, new BigDecimal("75000.00"), "Dell XPS 15"));
            productRepo.save(new Product(null, "Mouse", "Electronics", 8, new BigDecimal("1500.00"), "Wireless mouse"));
            productRepo.save(new Product(null, "Keyboard", "Electronics", 5, new BigDecimal("2000.00"), "Mechanical keyboard"));
            productRepo.save(new Product(null, "Desk Chair", "Furniture", 12, new BigDecimal("12000.00"), "Ergonomic chair"));
            productRepo.save(new Product(null, "Monitor", "Electronics", 3, new BigDecimal("25000.00"), "27-inch 4K monitor"));
            productRepo.save(new Product(null, "Notebook", "Stationery", 100, new BigDecimal("50.00"), "A4 ruled notebook"));

            System.out.println("=== Inventory Management System Started ===");
            System.out.println("H2 Console: http://localhost:8080/h2-console");
            System.out.println("API Base:   http://localhost:8080/api");
            System.out.println("Login: POST /api/auth/login");
            System.out.println("  Admin    -> admin / admin123");
            System.out.println("  Manager  -> manager / manager123");
            System.out.println("  Viewer   -> viewer / viewer123");
        };
    }
}
